<?php

//salario = $dia * $valordia;

$nome = "Isabela"; //declarando variavel e atribuindo valor tipo string
$sobrenome = "Vasconcelos";
$idade = 16;
$numero = 2024;
$dia = 22;
$valordia = 90.35;
$salario= " ";
$salario = $dia * $valordia;

//CALCULADORA 
/* TEXTO */
#TESTE
$a=10;
$b=20;
$soma;
$subtração;
$multiplicacao;
$divisao;



echo ("Nome: ".$nome. "<br>");
echo ("Sobrenome: ".$sobrenome."<br>");
echo ("Nome Completo: ".$nome. " " .$sobrenome."<br>");
echo ("Idade: ".$idade."<br>");
print ("Número: ".$numero."<br>");
print ("Dia: ".$dia."<br>");
print ("Valor dia: ".$valordia."<br>");
print ("Salário: R$ ".$salario."<br>");

print ("##############################################");
$a = 10;
$b = 10;
$soma;
$subtracao;
$multiplicacao;
$divisao;

$soma = $a + $b;
$subtracao = $a - $b;
$multiplicacao = $a * $b;
$divisao = $a / $b;

echo ("".$soma. "<br>");
echo ("".$subtracao. "<br>");
echo ("".$multiplicacao. "<br>");
echo ("".$divisao. "<br>");
print ("#####################################################");

var_dump(5);
var_dump("Isabela");
var_dump(3.14);
var_dump(true);
var_dump(2, 3, 56);
var_dump(NULL);

print ("<br>"."########################################################");

