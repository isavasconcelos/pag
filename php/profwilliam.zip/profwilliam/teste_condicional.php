<?php 
if (5>3) {
   echo "Have a good day and a good idea xx!";
}
echo"<br>";
echo "###########################################";
echo"<br>";
if (3<5) {
    echo "Have a good day and a good idea! yy";
}
echo"<br>";
echo "###########################################";
echo"<br>";
$y=14;
if ($y==20) {
    echo "Have a good day and a good idea xx!";
 }
 echo"<br>";
 echo "###########################################";
 echo"<br>";
 $y=14;
if ($y==20) {
    echo "Have a good day and a good idea xx!";
 } else {
    echo "Not have a good day and a good idea!";
 }
 echo"<br>";
 echo "###########################################";
 echo"<br>";

$z = date("H") - 3;

echo ("$z");
echo "<br>";

if ($z < "19"){
    echo "Good day!";
} else {
    echo "Have a good night!";
}
 echo"<br>";
 echo "###########################################";
 echo"<br>";
?>