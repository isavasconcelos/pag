<?php
echo "<br>";
echo "###########################";
echo "<br>";
echo (pi());
echo "<br>";
echo "###########################";
echo "<br>";
echo (min(0, 150, 30, 20, -8, -200));
echo "<br>";
echo "###########################";
echo "<br>";
echo (max(0, 150, 30, 20, -8, -200));
echo "<br>";
echo "###########################";
echo "<br>";
echo (sqrt(25)*5);
echo "<br>";
echo "###########################";
echo "<br>";
echo (rand());
echo "<br>";
echo "###########################";
echo "<br>";
echo ($letra = chr(64+rand(0,25)));
?>